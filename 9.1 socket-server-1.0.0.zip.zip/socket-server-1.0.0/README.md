

# Socket-Server


Reconstruir módulos de Node
```
npm install
```

Generar el DIST
```
tsc -w
```

Levantar servidor, cualquiera de estos dos comandos
```
nodemon dist/
node dist/
```



