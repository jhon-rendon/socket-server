

export const SERVER_PORT: number = Number( process.env.PORT ) || 5000;